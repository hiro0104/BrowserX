package com.android.browserx;

import android.app.Activity;
import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.FrameLayout;

public class FeatureMainContentLayout extends FrameLayout {

	public FeatureMainContentLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public FeatureMainContentLayout(Context context, AttributeSet attrs,
			int defStyle) {
		super(context, attrs, defStyle);
	}

	public FeatureMainContentLayout(Context context) {
		super(context);
	}

	private OnSoftKeyShownListener listener = null;
	
	public interface OnSoftKeyShownListener {
		public void onSoftKeyShown(boolean isShown);
	}

	public void setOnSoftKeyShownListener (OnSoftKeyShownListener listener) {
		this.listener = listener;
	}

	
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
//	    final int proposedheight = MeasureSpec.getSize(heightMeasureSpec);
//	    final int actualHeight = getHeight();
//
//	    if (listener != null) {
//	    	listener.onSoftKeyShown(actualHeight > proposedheight);
//	    }
//
//	    super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		// (a)View�̍���
		int viewHeight = MeasureSpec.getSize(heightMeasureSpec);
		// (b)�X�e�[�^�X�o�[�̍���
		Activity activity = (Activity) getContext();
		Rect rect = new Rect();
		activity.getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
		int statusBarHeight = rect.top;
		// (c)�f�B�X�v���C�T�C�Y
		int screenHeight = activity.getWindowManager().getDefaultDisplay()
				.getHeight();
		// (a)-(b)-(c)>100�s�N�Z���ƂȂ�����\�t�g�L�[�{�[�h���\������Ă�Ɣ��f
		//�i�\�t�g�L�[�{�[�h�͂ǂ�Ȃ��̂ł��Œ�100�s�N�Z������Ɖ���j
		int diff = (screenHeight - statusBarHeight) - viewHeight;
		if (listener != null) {
			listener.onSoftKeyShown(diff > 100);
		}
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
	}

	
}
